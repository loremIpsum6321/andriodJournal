package com.markrogers.journal.data.repo

import com.markrogers.journal.data.model.JournalEntry
import com.markrogers.journal.data.model.TodoItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.atomic.AtomicLong
import kotlin.random.Random

/**
 * Simple in-memory repo with StateFlows for entries and todos.
 * (Great for prototyping; swap for Room later.)
 */
object InMemoryRepository {

    // ---------- Generators ----------
    private val genEntry = AtomicLong(0)
    private val genTodo = AtomicLong(0)

    // ---------- State ----------
    private val _entries = MutableStateFlow<List<JournalEntry>>(emptyList())
    val entries: StateFlow<List<JournalEntry>> = _entries

    private val _todos = MutableStateFlow<List<TodoItem>>(emptyList())
    val todos: StateFlow<List<TodoItem>> = _todos

    // ---------- Entries ----------
    fun addEntry(
        title: String,
        body: String,
        moodEmojis: List<String>,
        moodRating: Int?,
        toggleX: Boolean,
        toggleY: Boolean,
        toggleZ: Boolean,
        toggleW: Boolean,
        sleepHours: Float,
        isTest: Boolean = false,
        createdAt: Instant = Instant.now()
    ): Long {
        val id = genEntry.incrementAndGet()
        val entry = JournalEntry(
            id = id,
            createdAt = createdAt,
            title = title,
            body = body,
            moodEmojis = moodEmojis,
            moodRating = moodRating,
            toggleX = toggleX,
            toggleY = toggleY,
            toggleZ = toggleZ,
            toggleW = toggleW,
            sleepHours = sleepHours,
            isTest = isTest
        )
        _entries.update { (it + entry).sortedBy { e -> e.createdAt } }
        return id
    }

    fun updateEntry(
        id: Long,
        title: String,
        body: String
    ) {
        _entries.update { list ->
            list.map { e ->
                if (e.id == id) e.copy(title = title, body = body) else e
            }
        }
    }

    fun deleteEntry(id: Long) {
        _entries.update { it.filterNot { e -> e.id == id } }
    }

    fun entriesInRange(start: LocalDate, end: LocalDate): List<JournalEntry> {
        val zone = ZoneId.systemDefault()
        val startInstant = start.atStartOfDay(zone).toInstant()
        val endExclusive = end.plusDays(1).atStartOfDay(zone).toInstant()
        return _entries.value.filter { it.createdAt >= startInstant && it.createdAt < endExclusive }
    }
    /** Re-inserts a previously deleted entry (used by Timeline undo). */
    fun restoreEntry(entry: com.markrogers.journal.data.model.JournalEntry) {
        _entries.update { list ->
            // If an entry with the same id already exists, keep the current list.
            if (list.any { it.id == entry.id }) list
            else (list + entry).sortedBy { it.createdAt }
        }
    }

    // ---------- Dummy / test data ----------
    fun generateDummyData(start: LocalDate, end: LocalDate, perDay: Int = 2) {
        val rnd = Random(42)
        val zone = ZoneId.systemDefault()
        val daySeq = generateSequence(start) { it.plusDays(1) }.takeWhile { !it.isAfter(end) }

        val toAdd = mutableListOf<JournalEntry>()
        daySeq.forEach { day ->
            repeat(perDay) {
                val id = genEntry.incrementAndGet()
                val createdAt = day
                    .atTime(rnd.nextInt(0, 23), rnd.nextInt(0, 59))
                    .atZone(zone)
                    .toInstant()
                val moodPalette = listOf("😀","🙂","😐","🙁","😢","🤩","😴","😤","😍","🥹")
                val moods = List(rnd.nextInt(1, 4)) { moodPalette.random(rnd) }.distinct()
                val rating = listOf(1, 2, 3, 4, 5).random(rnd)

                toAdd += JournalEntry(
                    id = id,
                    createdAt = createdAt,
                    title = "Entry $id",
                    body = "Generated entry $id.",
                    moodEmojis = moods,
                    moodRating = rating,
                    toggleX = rnd.nextBoolean(),
                    toggleY = rnd.nextBoolean(),
                    toggleZ = rnd.nextBoolean(),
                    toggleW = rnd.nextBoolean(),
                    sleepHours = rnd.nextInt(4, 10).toFloat(),
                    isTest = true
                )
            }
        }
        _entries.update { (it + toAdd).sortedBy { e -> e.createdAt } }
    }

    fun clearTestData() {
        _entries.update { it.filterNot { e -> e.isTest } }
    }

    // ---------- CSV (minimal & safe for our fields) ----------
    fun exportCsv(): String {
        val sb = StringBuilder()
        sb.appendLine("id,epochMillis,title,body,moods,moodRating,x,y,z,w,sleep,isTest")
        _entries.value.forEach { e ->
            fun esc(s: String) = s.replace("\"", "\"\"")
            val epoch = e.createdAt.toEpochMilli()
            val moods = e.moodEmojis.joinToString(";")

            sb.append(e.id).append(',')
                .append(epoch).append(',')
                .append('"').append(esc(e.title)).append('"').append(',')
                .append('"').append(esc(e.body)).append('"').append(',')
                .append('"').append(esc(moods)).append('"').append(',')
                .append(e.moodRating ?: "").append(',')
                .append(if (e.toggleX) 1 else 0).append(',')
                .append(if (e.toggleY) 1 else 0).append(',')
                .append(if (e.toggleZ) 1 else 0).append(',')
                .append(if (e.toggleW) 1 else 0).append(',')
                .append(e.sleepHours).append(',')
                .append(if (e.isTest) 1 else 0)
                .append('\n')
        }
        return sb.toString()
    }

    fun importCsv(csv: String) {
        val lines = csv.lineSequence().toList()
        if (lines.isEmpty()) return

        val zone = ZoneId.systemDefault()
        val out = mutableListOf<JournalEntry>()

        lines.drop(1).forEach { line ->
            if (line.isBlank()) return@forEach
            val p = parseCsvLine(line)
            if (p.size < 12) return@forEach

            val id = p[0].toLongOrNull() ?: genEntry.incrementAndGet()
            val created = Instant.ofEpochMilli(p[1].toLongOrNull() ?: System.currentTimeMillis())
            val title = p[2]
            val body = p[3]
            val moods = if (p[4].isBlank()) emptyList() else p[4].split(';')
            val moodRating = p[5].toIntOrNull()
            val x = p[6] == "1"
            val y = p[7] == "1"
            val z = p[8] == "1"
            val w = p[9] == "1"
            val sleep = p[10].toFloatOrNull() ?: 0f
            val isTest = p[11] == "1"

            out += JournalEntry(
                id = id,
                createdAt = created,
                title = title,
                body = body,
                moodEmojis = moods,
                moodRating = moodRating,
                toggleX = x,
                toggleY = y,
                toggleZ = z,
                toggleW = w,
                sleepHours = sleep,
                isTest = isTest
            )
        }
        _entries.update { (it + out).distinctBy { e -> e.id }.sortedBy { e -> e.createdAt } }
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            if (ch == '"') {
                if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                    sb.append('"'); i++ // escaped quote
                } else {
                    inQuotes = !inQuotes
                }
            } else if (ch == ',' && !inQuotes) {
                out += sb.toString()
                sb.setLength(0)
            } else {
                sb.append(ch)
            }
            i++
        }
        out += sb.toString()
        return out
    }

    // ---------- Todos ----------
    fun addTodo(date: LocalDate, text: String): Long {
        val id = genTodo.incrementAndGet()
        val item = TodoItem(id = id, date = date, text = text, done = false)
        _todos.update { it + item }
        return id
    }

    fun toggleTodo(id: Long) {
        _todos.update { list ->
            list.map { if (it.id == id) it.copy(done = !it.done) else it }
        }
    }

    fun todosOn(date: LocalDate): List<TodoItem> =
        _todos.value.filter { it.date == date }
}

package com.markrogers.journal.ui.timeline

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.markrogers.journal.data.model.JournalEntry
import com.markrogers.journal.data.repo.InMemoryRepository
import kotlinx.coroutines.launch
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimelineScreen(
    onNewEntry: () -> Unit = {}
) {
    val entries by InMemoryRepository.entries.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNewEntry,
                icon = { Icon(Icons.Filled.Add, contentDescription = "New") },
                text = { Text("New") }
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
        ) {
            items(entries, key = { it.id }) { e: JournalEntry ->
                val dismissState = rememberSwipeToDismissBoxState(
                    confirmValueChange = { value ->
                        if (value == SwipeToDismissBoxValue.EndToStart ||
                            value == SwipeToDismissBoxValue.StartToEnd
                        ) {
                            InMemoryRepository.deleteEntry(e.id)
                            scope.launch {
                                val result = snackbar.showSnackbar(
                                    message = "Entry deleted",
                                    actionLabel = "Undo",
                                    withDismissAction = true,
                                    duration = SnackbarDuration.Short
                                )
                                if (result == SnackbarResult.ActionPerformed) {
                                    InMemoryRepository.restoreEntry(e)
                                }
                            }
                            true
                        } else false
                    }
                )
                SwipeToDismissBox(
                    state = dismissState,
                    backgroundContent = { /* optional red background */ }
                ) {
                    TimelineRow(e)
                }
            }
        }
    }
}

@Composable
private fun TimelineRow(e: JournalEntry) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            // Title + date
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (e.title.isNotBlank()) e.title else "(untitled)",
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                val stamp = remember(e.createdAt) {
                    val dt = e.createdAt.atZone(ZoneId.systemDefault()).toLocalDateTime()
                    dt.format(DateTimeFormatter.ofPattern("MMM d, h:mm a"))
                }
                Text(
                    text = stamp,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Mood emojis
            if (e.moodEmojis.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    e.moodEmojis.take(3).forEach { emoji ->
                        Text(emoji, style = MaterialTheme.typography.titleLarge)
                    }
                }
            }

            // Body preview
            if (e.body.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = e.body,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Toggles + sleep summary
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (e.toggleX) Text("X", style = MaterialTheme.typography.labelMedium)
                if (e.toggleY) Text("Y", style = MaterialTheme.typography.labelMedium)
                if (e.toggleZ) Text("Z", style = MaterialTheme.typography.labelMedium)
                if (e.toggleW) Text("W", style = MaterialTheme.typography.labelMedium)
                Text(
                    "Sleep: ${"%.1f".format(e.sleepHours)}h",
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

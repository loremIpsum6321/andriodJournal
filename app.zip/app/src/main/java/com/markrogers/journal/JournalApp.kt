package com.markrogers.journal

import android.app.Application

class JournalApp : Application()
